﻿namespace POS_SALES
{
    partial class Report
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.rp15 = new System.Windows.Forms.RadioButton();
            this.rp13 = new System.Windows.Forms.RadioButton();
            this.rp12 = new System.Windows.Forms.RadioButton();
            this.rp11 = new System.Windows.Forms.RadioButton();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.rp9 = new System.Windows.Forms.RadioButton();
            this.rp8 = new System.Windows.Forms.RadioButton();
            this.rp7 = new System.Windows.Forms.RadioButton();
            this.rp10 = new System.Windows.Forms.RadioButton();
            this.rp2 = new System.Windows.Forms.RadioButton();
            this.date = new System.Windows.Forms.RadioButton();
            this.rp14 = new System.Windows.Forms.RadioButton();
            this.rp3 = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.mode = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbgroup = new System.Windows.Forms.ComboBox();
            this.rp20 = new System.Windows.Forms.RadioButton();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.rp1 = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rp35 = new System.Windows.Forms.RadioButton();
            this.rp36 = new System.Windows.Forms.RadioButton();
            this.rp34 = new System.Windows.Forms.RadioButton();
            this.rp33 = new System.Windows.Forms.RadioButton();
            this.rp32 = new System.Windows.Forms.RadioButton();
            this.rp30 = new System.Windows.Forms.RadioButton();
            this.rp31 = new System.Windows.Forms.RadioButton();
            this.rp29 = new System.Windows.Forms.RadioButton();
            this.rp28 = new System.Windows.Forms.RadioButton();
            this.rp26 = new System.Windows.Forms.RadioButton();
            this.rp21 = new System.Windows.Forms.RadioButton();
            this.rp24 = new System.Windows.Forms.RadioButton();
            this.rp27 = new System.Windows.Forms.RadioButton();
            this.rp19 = new System.Windows.Forms.RadioButton();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(10, 11);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Select Cashier";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker2.Location = new System.Drawing.Point(92, 32);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(91, 20);
            this.dateTimePicker2.TabIndex = 2;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(91, 4);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(91, 20);
            this.dateTimePicker1.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(20, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "Date To:";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.dateTimePicker2);
            this.panel4.Controls.Add(this.dateTimePicker1);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Location = new System.Drawing.Point(0, 26);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(193, 64);
            this.panel4.TabIndex = 1;
            this.panel4.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(10, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Date From:";
            // 
            // rp15
            // 
            this.rp15.AutoSize = true;
            this.rp15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rp15.Location = new System.Drawing.Point(562, 216);
            this.rp15.Name = "rp15";
            this.rp15.Size = new System.Drawing.Size(158, 20);
            this.rp15.TabIndex = 4;
            this.rp15.TabStop = true;
            this.rp15.Text = "Re-Print Sales Invoice";
            this.rp15.UseVisualStyleBackColor = true;
            this.rp15.Visible = false;
            this.rp15.CheckedChanged += new System.EventHandler(this.rp15_CheckedChanged);
            // 
            // rp13
            // 
            this.rp13.AutoSize = true;
            this.rp13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rp13.Location = new System.Drawing.Point(16, 190);
            this.rp13.Name = "rp13";
            this.rp13.Size = new System.Drawing.Size(192, 20);
            this.rp13.TabIndex = 3;
            this.rp13.TabStop = true;
            this.rp13.Text = "Detail Sales && Stock Report";
            this.rp13.UseVisualStyleBackColor = true;
            this.rp13.CheckedChanged += new System.EventHandler(this.rp13_CheckedChanged);
            // 
            // rp12
            // 
            this.rp12.AutoSize = true;
            this.rp12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rp12.Location = new System.Drawing.Point(99, -1);
            this.rp12.Name = "rp12";
            this.rp12.Size = new System.Drawing.Size(130, 20);
            this.rp12.TabIndex = 3;
            this.rp12.TabStop = true;
            this.rp12.Text = "Product Returned";
            this.rp12.UseVisualStyleBackColor = true;
            this.rp12.Visible = false;
            this.rp12.CheckedChanged += new System.EventHandler(this.rp12_CheckedChanged);
            // 
            // rp11
            // 
            this.rp11.AutoSize = true;
            this.rp11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rp11.Location = new System.Drawing.Point(247, 96);
            this.rp11.Name = "rp11";
            this.rp11.Size = new System.Drawing.Size(111, 20);
            this.rp11.TabIndex = 3;
            this.rp11.TabStop = true;
            this.rp11.Text = "Re - Order List";
            this.rp11.UseVisualStyleBackColor = true;
            this.rp11.Visible = false;
            this.rp11.CheckedChanged += new System.EventHandler(this.rp11_CheckedChanged);
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Checked = true;
            this.radioButton10.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton10.Location = new System.Drawing.Point(142, 3);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(78, 20);
            this.radioButton10.TabIndex = 0;
            this.radioButton10.TabStop = true;
            this.radioButton10.Text = "To Date";
            this.radioButton10.UseVisualStyleBackColor = true;
            // 
            // rp9
            // 
            this.rp9.AutoSize = true;
            this.rp9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rp9.Location = new System.Drawing.Point(16, 164);
            this.rp9.Name = "rp9";
            this.rp9.Size = new System.Drawing.Size(113, 20);
            this.rp9.TabIndex = 3;
            this.rp9.TabStop = true;
            this.rp9.Text = "Product Listing";
            this.rp9.UseVisualStyleBackColor = true;
            this.rp9.CheckedChanged += new System.EventHandler(this.rp9_CheckedChanged);
            // 
            // rp8
            // 
            this.rp8.AutoSize = true;
            this.rp8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rp8.Location = new System.Drawing.Point(16, 88);
            this.rp8.Name = "rp8";
            this.rp8.Size = new System.Drawing.Size(158, 20);
            this.rp8.TabIndex = 3;
            this.rp8.TabStop = true;
            this.rp8.Text = "Stock Valuation Liquid";
            this.rp8.UseVisualStyleBackColor = true;
            this.rp8.CheckedChanged += new System.EventHandler(this.rp8_CheckedChanged);
            // 
            // rp7
            // 
            this.rp7.AutoSize = true;
            this.rp7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rp7.Location = new System.Drawing.Point(16, 11);
            this.rp7.Name = "rp7";
            this.rp7.Size = new System.Drawing.Size(150, 20);
            this.rp7.TabIndex = 3;
            this.rp7.TabStop = true;
            this.rp7.Text = "Stock Position Liquid";
            this.rp7.UseVisualStyleBackColor = true;
            this.rp7.CheckedChanged += new System.EventHandler(this.rp7_CheckedChanged);
            // 
            // rp10
            // 
            this.rp10.AutoSize = true;
            this.rp10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rp10.Location = new System.Drawing.Point(301, 163);
            this.rp10.Name = "rp10";
            this.rp10.Size = new System.Drawing.Size(290, 20);
            this.rp10.TabIndex = 2;
            this.rp10.TabStop = true;
            this.rp10.Text = "General Sales Transaction Report Summary";
            this.rp10.UseVisualStyleBackColor = true;
            this.rp10.CheckedChanged += new System.EventHandler(this.rp10_CheckedChanged);
            // 
            // rp2
            // 
            this.rp2.AutoSize = true;
            this.rp2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rp2.Location = new System.Drawing.Point(301, 112);
            this.rp2.Name = "rp2";
            this.rp2.Size = new System.Drawing.Size(197, 20);
            this.rp2.TabIndex = 0;
            this.rp2.TabStop = true;
            this.rp2.Text = "Sales Analysis Report Detail";
            this.rp2.UseVisualStyleBackColor = true;
            this.rp2.CheckedChanged += new System.EventHandler(this.rp2_CheckedChanged);
            // 
            // date
            // 
            this.date.AutoSize = true;
            this.date.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date.Location = new System.Drawing.Point(21, 3);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(102, 20);
            this.date.TabIndex = 0;
            this.date.Text = "Date Range";
            this.date.UseVisualStyleBackColor = true;
            this.date.CheckedChanged += new System.EventHandler(this.date_CheckedChanged);
            // 
            // rp14
            // 
            this.rp14.AutoSize = true;
            this.rp14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rp14.Location = new System.Drawing.Point(562, 242);
            this.rp14.Name = "rp14";
            this.rp14.Size = new System.Drawing.Size(187, 20);
            this.rp14.TabIndex = 0;
            this.rp14.TabStop = true;
            this.rp14.Text = "Sales Analysis Profile (P/L)";
            this.rp14.UseVisualStyleBackColor = true;
            this.rp14.Visible = false;
            this.rp14.CheckedChanged += new System.EventHandler(this.rp14_CheckedChanged);
            // 
            // rp3
            // 
            this.rp3.AutoSize = true;
            this.rp3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rp3.Location = new System.Drawing.Point(301, 138);
            this.rp3.Name = "rp3";
            this.rp3.Size = new System.Drawing.Size(224, 20);
            this.rp3.TabIndex = 0;
            this.rp3.TabStop = true;
            this.rp3.Text = "Detail Sales Analysis  By Cashier";
            this.rp3.UseVisualStyleBackColor = true;
            this.rp3.CheckedChanged += new System.EventHandler(this.rp3_CheckedChanged);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Location = new System.Drawing.Point(27, 295);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(586, 119);
            this.panel2.TabIndex = 1;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.panel3);
            this.groupBox2.Controls.Add(this.rp20);
            this.groupBox2.Controls.Add(this.rp12);
            this.groupBox2.Controls.Add(this.rp11);
            this.groupBox2.Location = new System.Drawing.Point(-2, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(579, 113);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Select A Period";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.radioButton10);
            this.panel3.Controls.Add(this.date);
            this.panel3.Location = new System.Drawing.Point(7, 19);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(567, 90);
            this.panel3.TabIndex = 0;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.comboBox2);
            this.panel5.Controls.Add(this.mode);
            this.panel5.Controls.Add(this.label5);
            this.panel5.Controls.Add(this.cmbgroup);
            this.panel5.Controls.Add(this.label4);
            this.panel5.Location = new System.Drawing.Point(221, 15);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(345, 75);
            this.panel5.TabIndex = 4;
            this.panel5.Visible = false;
            // 
            // comboBox2
            // 
            this.comboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.comboBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(93, 40);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(249, 28);
            this.comboBox2.TabIndex = 23;
            this.comboBox2.Visible = false;
            // 
            // mode
            // 
            this.mode.Location = new System.Drawing.Point(198, 14);
            this.mode.Name = "mode";
            this.mode.Size = new System.Drawing.Size(100, 20);
            this.mode.TabIndex = 24;
            this.mode.Text = "CREDIT SALES";
            this.mode.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(7, 45);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 15);
            this.label5.TabIndex = 22;
            this.label5.Text = "Select Vendor";
            this.label5.Visible = false;
            // 
            // cmbgroup
            // 
            this.cmbgroup.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbgroup.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.cmbgroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbgroup.FormattingEnabled = true;
            this.cmbgroup.Items.AddRange(new object[] {
            "MALE",
            "FEMALE"});
            this.cmbgroup.Location = new System.Drawing.Point(104, 6);
            this.cmbgroup.Name = "cmbgroup";
            this.cmbgroup.Size = new System.Drawing.Size(238, 28);
            this.cmbgroup.TabIndex = 21;
            // 
            // rp20
            // 
            this.rp20.AutoSize = true;
            this.rp20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rp20.Location = new System.Drawing.Point(301, 0);
            this.rp20.Name = "rp20";
            this.rp20.Size = new System.Drawing.Size(177, 20);
            this.rp20.TabIndex = 9;
            this.rp20.TabStop = true;
            this.rp20.Text = "View Sales Invoice Detail";
            this.rp20.UseVisualStyleBackColor = true;
            this.rp20.Visible = false;
            this.rp20.CheckedChanged += new System.EventHandler(this.rp20_CheckedChanged);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(382, 445);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(126, 20);
            this.textBox2.TabIndex = 3;
            this.textBox2.Visible = false;
            // 
            // rp1
            // 
            this.rp1.AutoSize = true;
            this.rp1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rp1.Location = new System.Drawing.Point(301, 86);
            this.rp1.Name = "rp1";
            this.rp1.Size = new System.Drawing.Size(339, 20);
            this.rp1.TabIndex = 0;
            this.rp1.TabStop = true;
            this.rp1.Text = "Sales Analysis Report Summary By Payment Modes";
            this.rp1.UseVisualStyleBackColor = true;
            this.rp1.CheckedChanged += new System.EventHandler(this.rp1_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Window;
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(666, 470);
            this.panel1.TabIndex = 2;
            // 
            // button2
            // 
            this.button2.Enabled = false;
            this.button2.Location = new System.Drawing.Point(434, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(105, 29);
            this.button2.TabIndex = 3;
            this.button2.Text = "Print";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(293, 11);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(118, 29);
            this.button1.TabIndex = 3;
            this.button1.Text = "Preview";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.Enabled = false;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(138, 17);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(132, 21);
            this.comboBox1.TabIndex = 2;
            this.comboBox1.Text = "ALL";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Report Option";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rp35);
            this.groupBox1.Controls.Add(this.rp36);
            this.groupBox1.Controls.Add(this.rp34);
            this.groupBox1.Controls.Add(this.rp15);
            this.groupBox1.Controls.Add(this.rp33);
            this.groupBox1.Controls.Add(this.rp32);
            this.groupBox1.Controls.Add(this.rp14);
            this.groupBox1.Controls.Add(this.rp30);
            this.groupBox1.Controls.Add(this.rp31);
            this.groupBox1.Controls.Add(this.rp29);
            this.groupBox1.Controls.Add(this.panel2);
            this.groupBox1.Controls.Add(this.rp28);
            this.groupBox1.Controls.Add(this.rp26);
            this.groupBox1.Controls.Add(this.rp21);
            this.groupBox1.Controls.Add(this.rp24);
            this.groupBox1.Controls.Add(this.rp27);
            this.groupBox1.Controls.Add(this.rp19);
            this.groupBox1.Controls.Add(this.rp13);
            this.groupBox1.Controls.Add(this.rp9);
            this.groupBox1.Controls.Add(this.rp8);
            this.groupBox1.Controls.Add(this.rp7);
            this.groupBox1.Controls.Add(this.rp10);
            this.groupBox1.Controls.Add(this.rp3);
            this.groupBox1.Controls.Add(this.rp2);
            this.groupBox1.Controls.Add(this.rp1);
            this.groupBox1.Location = new System.Drawing.Point(9, 44);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(645, 403);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // rp35
            // 
            this.rp35.AutoSize = true;
            this.rp35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rp35.Location = new System.Drawing.Point(301, 60);
            this.rp35.Name = "rp35";
            this.rp35.Size = new System.Drawing.Size(269, 20);
            this.rp35.TabIndex = 31;
            this.rp35.TabStop = true;
            this.rp35.Text = "Daily Sales Analysis By Payment Modes";
            this.rp35.UseVisualStyleBackColor = true;
            this.rp35.CheckedChanged += new System.EventHandler(this.rp35_CheckedChanged);
            // 
            // rp36
            // 
            this.rp36.AutoSize = true;
            this.rp36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rp36.Location = new System.Drawing.Point(301, 269);
            this.rp36.Name = "rp36";
            this.rp36.Size = new System.Drawing.Size(211, 20);
            this.rp36.TabIndex = 30;
            this.rp36.TabStop = true;
            this.rp36.Text = "Suppliers Statement of Account";
            this.rp36.UseVisualStyleBackColor = true;
            this.rp36.CheckedChanged += new System.EventHandler(this.rp36_CheckedChanged);
            // 
            // rp34
            // 
            this.rp34.AutoSize = true;
            this.rp34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rp34.Location = new System.Drawing.Point(16, 62);
            this.rp34.Name = "rp34";
            this.rp34.Size = new System.Drawing.Size(223, 20);
            this.rp34.TabIndex = 29;
            this.rp34.TabStop = true;
            this.rp34.Text = "Stock Position Empties Summary";
            this.rp34.UseVisualStyleBackColor = true;
            this.rp34.CheckedChanged += new System.EventHandler(this.rp34_CheckedChanged);
            // 
            // rp33
            // 
            this.rp33.AutoSize = true;
            this.rp33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rp33.Location = new System.Drawing.Point(16, 244);
            this.rp33.Name = "rp33";
            this.rp33.Size = new System.Drawing.Size(261, 20);
            this.rp33.TabIndex = 28;
            this.rp33.TabStop = true;
            this.rp33.Text = "Detail Empties Refund (Deposit) Report";
            this.rp33.UseVisualStyleBackColor = true;
            this.rp33.CheckedChanged += new System.EventHandler(this.rp33_CheckedChanged);
            // 
            // rp32
            // 
            this.rp32.AutoSize = true;
            this.rp32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rp32.Location = new System.Drawing.Point(16, 269);
            this.rp32.Name = "rp32";
            this.rp32.Size = new System.Drawing.Size(275, 20);
            this.rp32.TabIndex = 27;
            this.rp32.TabStop = true;
            this.rp32.Text = "Detail Empties Purchase (Deposit) Report";
            this.rp32.UseVisualStyleBackColor = true;
            this.rp32.CheckedChanged += new System.EventHandler(this.rp32_CheckedChanged);
            // 
            // rp30
            // 
            this.rp30.AutoSize = true;
            this.rp30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rp30.Location = new System.Drawing.Point(16, 112);
            this.rp30.Name = "rp30";
            this.rp30.Size = new System.Drawing.Size(171, 20);
            this.rp30.TabIndex = 26;
            this.rp30.TabStop = true;
            this.rp30.Text = "Stock Valuation Empties";
            this.rp30.UseVisualStyleBackColor = true;
            this.rp30.CheckedChanged += new System.EventHandler(this.rp30_CheckedChanged);
            // 
            // rp31
            // 
            this.rp31.AutoSize = true;
            this.rp31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rp31.Location = new System.Drawing.Point(301, 36);
            this.rp31.Name = "rp31";
            this.rp31.Size = new System.Drawing.Size(262, 20);
            this.rp31.TabIndex = 25;
            this.rp31.TabStop = true;
            this.rp31.Text = "Detail Profit Analysis Report Using FIFO";
            this.rp31.UseVisualStyleBackColor = true;
            this.rp31.CheckedChanged += new System.EventHandler(this.rp31_CheckedChanged);
            // 
            // rp29
            // 
            this.rp29.AutoSize = true;
            this.rp29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rp29.Location = new System.Drawing.Point(16, 37);
            this.rp29.Name = "rp29";
            this.rp29.Size = new System.Drawing.Size(201, 20);
            this.rp29.TabIndex = 23;
            this.rp29.TabStop = true;
            this.rp29.Text = "Stock Position Empties Detail";
            this.rp29.UseVisualStyleBackColor = true;
            this.rp29.CheckedChanged += new System.EventHandler(this.rp29_CheckedChanged);
            // 
            // rp28
            // 
            this.rp28.AutoSize = true;
            this.rp28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rp28.Location = new System.Drawing.Point(16, 138);
            this.rp28.Name = "rp28";
            this.rp28.Size = new System.Drawing.Size(249, 20);
            this.rp28.TabIndex = 22;
            this.rp28.TabStop = true;
            this.rp28.Text = "Empties Stock Inflow/Outflow Analysis";
            this.rp28.UseVisualStyleBackColor = true;
            this.rp28.CheckedChanged += new System.EventHandler(this.rp28_CheckedChanged);
            // 
            // rp26
            // 
            this.rp26.AutoSize = true;
            this.rp26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rp26.Location = new System.Drawing.Point(301, 243);
            this.rp26.Name = "rp26";
            this.rp26.Size = new System.Drawing.Size(210, 20);
            this.rp26.TabIndex = 21;
            this.rp26.TabStop = true;
            this.rp26.Text = "Customers Credit Sales Report";
            this.rp26.UseVisualStyleBackColor = true;
            this.rp26.CheckedChanged += new System.EventHandler(this.rp26_CheckedChanged);
            // 
            // rp21
            // 
            this.rp21.AutoSize = true;
            this.rp21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rp21.Location = new System.Drawing.Point(301, 10);
            this.rp21.Name = "rp21";
            this.rp21.Size = new System.Drawing.Size(285, 20);
            this.rp21.TabIndex = 11;
            this.rp21.TabStop = true;
            this.rp21.Text = "Product Profit Analysis Report By Projection";
            this.rp21.UseVisualStyleBackColor = true;
            this.rp21.CheckedChanged += new System.EventHandler(this.rp21_CheckedChanged);
            // 
            // rp24
            // 
            this.rp24.AutoSize = true;
            this.rp24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rp24.Location = new System.Drawing.Point(301, 217);
            this.rp24.Name = "rp24";
            this.rp24.Size = new System.Drawing.Size(218, 20);
            this.rp24.TabIndex = 19;
            this.rp24.TabStop = true;
            this.rp24.Text = "Customers Statement of Account";
            this.rp24.UseVisualStyleBackColor = true;
            this.rp24.CheckedChanged += new System.EventHandler(this.rp24_CheckedChanged);
            // 
            // rp27
            // 
            this.rp27.AutoSize = true;
            this.rp27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rp27.Location = new System.Drawing.Point(301, 189);
            this.rp27.Name = "rp27";
            this.rp27.Size = new System.Drawing.Size(130, 20);
            this.rp27.TabIndex = 17;
            this.rp27.TabStop = true;
            this.rp27.Text = "Expenses Report";
            this.rp27.UseVisualStyleBackColor = true;
            this.rp27.CheckedChanged += new System.EventHandler(this.rp27_CheckedChanged);
            // 
            // rp19
            // 
            this.rp19.AutoSize = true;
            this.rp19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rp19.Location = new System.Drawing.Point(16, 216);
            this.rp19.Name = "rp19";
            this.rp19.Size = new System.Drawing.Size(253, 20);
            this.rp19.TabIndex = 10;
            this.rp19.TabStop = true;
            this.rp19.Text = "Purchase Analysis Report By Supplier";
            this.rp19.UseVisualStyleBackColor = true;
            this.rp19.CheckedChanged += new System.EventHandler(this.rp19_CheckedChanged);
            // 
            // Report
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(666, 470);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "Report";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Report";
            this.Load += new System.EventHandler(this.Report_Load);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton rp15;
        private System.Windows.Forms.RadioButton rp13;
        private System.Windows.Forms.RadioButton rp12;
        private System.Windows.Forms.RadioButton rp11;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.RadioButton rp9;
        private System.Windows.Forms.RadioButton rp8;
        private System.Windows.Forms.RadioButton rp7;
        private System.Windows.Forms.RadioButton rp10;
        private System.Windows.Forms.RadioButton rp2;
        private System.Windows.Forms.RadioButton date;
        private System.Windows.Forms.RadioButton rp14;
        private System.Windows.Forms.RadioButton rp3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.ComboBox cmbgroup;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.RadioButton rp1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton rp19;
        private System.Windows.Forms.RadioButton rp20;
        private System.Windows.Forms.RadioButton rp21;
        private System.Windows.Forms.RadioButton rp26;
        private System.Windows.Forms.RadioButton rp24;
        private System.Windows.Forms.RadioButton rp27;
        private System.Windows.Forms.RadioButton rp28;
        private System.Windows.Forms.RadioButton rp29;
        private System.Windows.Forms.TextBox mode;
        private System.Windows.Forms.RadioButton rp30;
        private System.Windows.Forms.RadioButton rp31;
        private System.Windows.Forms.RadioButton rp32;
        private System.Windows.Forms.RadioButton rp33;
        private System.Windows.Forms.RadioButton rp34;
        private System.Windows.Forms.RadioButton rp35;
        private System.Windows.Forms.RadioButton rp36;
    }
}