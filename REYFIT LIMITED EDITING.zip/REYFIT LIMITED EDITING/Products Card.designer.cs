﻿namespace POS_SALES
{
    partial class Products_Card
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ws_qty = new System.Windows.Forms.NumericUpDown();
            this.label15 = new System.Windows.Forms.Label();
            this.ws = new System.Windows.Forms.TextBox();
            this.lpd = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.lpc = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.wp = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.s_p = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.cp = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.dept = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.desc = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.stk = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.button5 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.stk_empty = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.discount = new System.Windows.Forms.TextBox();
            this.minimum_qty = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.pdc = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.barcode = new System.Windows.Forms.TextBox();
            this.ro = new System.Windows.Forms.NumericUpDown();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cont = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.ws_qty)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ro)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ws_qty
            // 
            this.ws_qty.Location = new System.Drawing.Point(110, 32);
            this.ws_qty.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.ws_qty.Name = "ws_qty";
            this.ws_qty.Size = new System.Drawing.Size(120, 20);
            this.ws_qty.TabIndex = 49;
            this.ws_qty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.ws_qty.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ws_qty_KeyDown);
            this.ws_qty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ws_qty_KeyPress);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(1, 8);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(106, 15);
            this.label15.TabIndex = 35;
            this.label15.Text = "Empty Bottle Price";
            // 
            // ws
            // 
            this.ws.Location = new System.Drawing.Point(109, 6);
            this.ws.Name = "ws";
            this.ws.Size = new System.Drawing.Size(122, 20);
            this.ws.TabIndex = 36;
            this.ws.Text = "0.00";
            this.ws.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.ws.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ws_KeyDown);
            this.ws.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ws_KeyPress);
            this.ws.Leave += new System.EventHandler(this.ws_Leave);
            // 
            // lpd
            // 
            this.lpd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lpd.Location = new System.Drawing.Point(138, 165);
            this.lpd.Name = "lpd";
            this.lpd.Size = new System.Drawing.Size(121, 20);
            this.lpd.TabIndex = 40;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(18, 168);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(114, 15);
            this.label20.TabIndex = 39;
            this.label20.Text = "Last Purchase Date";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold);
            this.button1.ForeColor = System.Drawing.Color.Navy;
            this.button1.Location = new System.Drawing.Point(220, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(57, 41);
            this.button1.TabIndex = 16;
            this.button1.Text = "How Liquid";
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lpc
            // 
            this.lpc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lpc.Location = new System.Drawing.Point(137, 140);
            this.lpc.Name = "lpc";
            this.lpc.Size = new System.Drawing.Size(121, 20);
            this.lpc.TabIndex = 38;
            this.lpc.Text = "0.00";
            this.lpc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(17, 141);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(112, 15);
            this.label17.TabIndex = 37;
            this.label17.Text = "Last Purchase Cost";
            // 
            // wp
            // 
            this.wp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.wp.Location = new System.Drawing.Point(137, 114);
            this.wp.Name = "wp";
            this.wp.Size = new System.Drawing.Size(121, 20);
            this.wp.TabIndex = 36;
            this.wp.Text = "0.00";
            this.wp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(71, 117);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(56, 15);
            this.label18.TabIndex = 35;
            this.label18.Text = "WA Price";
            // 
            // s_p
            // 
            this.s_p.Location = new System.Drawing.Point(116, 32);
            this.s_p.Name = "s_p";
            this.s_p.Size = new System.Drawing.Size(121, 20);
            this.s_p.TabIndex = 38;
            this.s_p.Text = "0.00";
            this.s_p.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.s_p.KeyDown += new System.Windows.Forms.KeyEventHandler(this.s_p_KeyDown);
            this.s_p.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.s_p_KeyPress);
            this.s_p.Leave += new System.EventHandler(this.s_p_Leave);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(33, 34);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(76, 15);
            this.label16.TabIndex = 37;
            this.label16.Text = "Selling Price";
            // 
            // cp
            // 
            this.cp.Location = new System.Drawing.Point(116, 9);
            this.cp.Name = "cp";
            this.cp.Size = new System.Drawing.Size(121, 20);
            this.cp.TabIndex = 34;
            this.cp.Text = "0.00";
            this.cp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.cp.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cp_KeyDown);
            this.cp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cp_KeyPress);
            this.cp.Leave += new System.EventHandler(this.cp_Leave);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(50, 9);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(62, 15);
            this.label14.TabIndex = 33;
            this.label14.Text = "Cost Price";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(0, 152);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(135, 15);
            this.label8.TabIndex = 28;
            this.label8.Text = "Re-Order Quantity Limit";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(66, 126);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(69, 15);
            this.label11.TabIndex = 26;
            this.label11.Text = "Expiry Date";
            // 
            // dept
            // 
            this.dept.FormattingEnabled = true;
            this.dept.Location = new System.Drawing.Point(136, 99);
            this.dept.Name = "dept";
            this.dept.Size = new System.Drawing.Size(160, 21);
            this.dept.TabIndex = 12;
            this.dept.SelectedIndexChanged += new System.EventHandler(this.dept_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(8, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 15);
            this.label2.TabIndex = 9;
            this.label2.Text = "Product Container";
            // 
            // desc
            // 
            this.desc.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.desc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.desc.Location = new System.Drawing.Point(136, 44);
            this.desc.Name = "desc";
            this.desc.Size = new System.Drawing.Size(363, 22);
            this.desc.TabIndex = 7;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(0, 44);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(133, 15);
            this.label9.TabIndex = 6;
            this.label9.Text = "Product Description";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(25, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 15);
            this.label1.TabIndex = 39;
            this.label1.Text = "Pack Quantity";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(40, 16);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(93, 15);
            this.label10.TabIndex = 4;
            this.label10.Text = "Product Code";
            // 
            // stk
            // 
            this.stk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.stk.Location = new System.Drawing.Point(139, 12);
            this.stk.Name = "stk";
            this.stk.ReadOnly = true;
            this.stk.Size = new System.Drawing.Size(78, 20);
            this.stk.TabIndex = 34;
            this.stk.Text = "0";
            this.stk.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.panel2);
            this.panel3.Controls.Add(this.s_p);
            this.panel3.Controls.Add(this.label16);
            this.panel3.Controls.Add(this.cp);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Location = new System.Drawing.Point(3, 178);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(292, 129);
            this.panel3.TabIndex = 32;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.ws_qty);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.ws);
            this.panel2.Location = new System.Drawing.Point(4, 58);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(284, 63);
            this.panel2.TabIndex = 39;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(37, 15);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(92, 15);
            this.label19.TabIndex = 33;
            this.label19.Text = "Inventory Liquid";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(136, 126);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(160, 20);
            this.dateTimePicker1.TabIndex = 46;
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.Red;
            this.button5.Location = new System.Drawing.Point(163, 313);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(93, 32);
            this.button5.TabIndex = 44;
            this.button5.Text = "&Cancel";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel4.Controls.Add(this.button3);
            this.panel4.Controls.Add(this.stk_empty);
            this.panel4.Controls.Add(this.label13);
            this.panel4.Controls.Add(this.label12);
            this.panel4.Controls.Add(this.discount);
            this.panel4.Controls.Add(this.minimum_qty);
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.lpd);
            this.panel4.Controls.Add(this.label20);
            this.panel4.Controls.Add(this.button1);
            this.panel4.Controls.Add(this.lpc);
            this.panel4.Controls.Add(this.label17);
            this.panel4.Controls.Add(this.wp);
            this.panel4.Controls.Add(this.label18);
            this.panel4.Controls.Add(this.stk);
            this.panel4.Controls.Add(this.label19);
            this.panel4.Location = new System.Drawing.Point(315, 145);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(287, 195);
            this.panel4.TabIndex = 39;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold);
            this.button3.ForeColor = System.Drawing.Color.Red;
            this.button3.Location = new System.Drawing.Point(220, 50);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(60, 41);
            this.button3.TabIndex = 52;
            this.button3.Text = "How Empties";
            this.button3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Visible = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // stk_empty
            // 
            this.stk_empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.stk_empty.Location = new System.Drawing.Point(139, 40);
            this.stk_empty.Name = "stk_empty";
            this.stk_empty.ReadOnly = true;
            this.stk_empty.Size = new System.Drawing.Size(78, 20);
            this.stk_empty.TabIndex = 51;
            this.stk_empty.Text = "0";
            this.stk_empty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(7, 41);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(126, 15);
            this.label13.TabIndex = 50;
            this.label13.Text = "Inventory Empty Bottle";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(0, 93);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(131, 15);
            this.label12.TabIndex = 49;
            this.label12.Text = "Minimum Qty Discount";
            // 
            // discount
            // 
            this.discount.BackColor = System.Drawing.Color.White;
            this.discount.Location = new System.Drawing.Point(139, 90);
            this.discount.Name = "discount";
            this.discount.Size = new System.Drawing.Size(78, 20);
            this.discount.TabIndex = 48;
            this.discount.Text = "0";
            this.discount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // minimum_qty
            // 
            this.minimum_qty.BackColor = System.Drawing.Color.White;
            this.minimum_qty.Location = new System.Drawing.Point(139, 66);
            this.minimum_qty.Name = "minimum_qty";
            this.minimum_qty.Size = new System.Drawing.Size(78, 20);
            this.minimum_qty.TabIndex = 46;
            this.minimum_qty.Text = "0";
            this.minimum_qty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(49, 69);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(80, 15);
            this.label7.TabIndex = 45;
            this.label7.Text = "Minimum Qty";
            // 
            // pdc
            // 
            this.pdc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.pdc.Location = new System.Drawing.Point(136, 15);
            this.pdc.Name = "pdc";
            this.pdc.ReadOnly = true;
            this.pdc.Size = new System.Drawing.Size(159, 20);
            this.pdc.TabIndex = 5;
            this.pdc.Text = "AUTO";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(1, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 15);
            this.label3.TabIndex = 35;
            this.label3.Text = "Barcode";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(86, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(96, 15);
            this.label5.TabIndex = 35;
            this.label5.Text = "Scan Barcode";
            // 
            // barcode
            // 
            this.barcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.barcode.Location = new System.Drawing.Point(60, 23);
            this.barcode.Name = "barcode";
            this.barcode.Size = new System.Drawing.Size(217, 22);
            this.barcode.TabIndex = 36;
            this.barcode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ro
            // 
            this.ro.Location = new System.Drawing.Point(136, 152);
            this.ro.Name = "ro";
            this.ro.Size = new System.Drawing.Size(120, 20);
            this.ro.TabIndex = 48;
            this.ro.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel5.Controls.Add(this.label3);
            this.panel5.Controls.Add(this.label5);
            this.panel5.Controls.Add(this.barcode);
            this.panel5.Location = new System.Drawing.Point(315, 77);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(284, 62);
            this.panel5.TabIndex = 47;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Window;
            this.panel1.Controls.Add(this.cont);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.ro);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.dateTimePicker1);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.dept);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.desc);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.pdc);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(607, 369);
            this.panel1.TabIndex = 4;
            // 
            // cont
            // 
            this.cont.FormattingEnabled = true;
            this.cont.Items.AddRange(new object[] {
            "BOTTLE",
            "CAN",
            "PET"});
            this.cont.Location = new System.Drawing.Point(136, 73);
            this.cont.Name = "cont";
            this.cont.Size = new System.Drawing.Size(160, 21);
            this.cont.TabIndex = 51;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(16, 100);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(116, 15);
            this.label6.TabIndex = 50;
            this.label6.Text = "Product Category";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Red;
            this.button2.Location = new System.Drawing.Point(57, 313);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(93, 32);
            this.button2.TabIndex = 49;
            this.button2.Text = "Save";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(528, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 45;
            this.label4.Text = "label4";
            this.label4.Visible = false;
            // 
            // Products_Card
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(607, 373);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Products_Card";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Products_Card";
            this.Load += new System.EventHandler(this.Products_Card_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ws_qty)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ro)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.NumericUpDown ws_qty;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox ws;
        private System.Windows.Forms.TextBox lpd;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox lpc;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox wp;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox s_p;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox cp;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox dept;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox desc;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox stk;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox pdc;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox barcode;
        private System.Windows.Forms.NumericUpDown ro;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox cont;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox discount;
        private System.Windows.Forms.TextBox minimum_qty;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox stk_empty;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button3;
    }
}